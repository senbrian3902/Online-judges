from judge.tasks.contest import *
from judge.tasks.demo import *
from judge.tasks.submission import *
from judge.tasks.user import *
