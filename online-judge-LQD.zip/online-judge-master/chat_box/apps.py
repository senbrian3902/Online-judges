from django.apps import AppConfig


class ChatBoxConfig(AppConfig):
    name = "chat_box"
