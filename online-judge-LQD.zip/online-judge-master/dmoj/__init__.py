from dmoj.celery import app as celery_app
