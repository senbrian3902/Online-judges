from judge.tasks.contest import *
from judge.tasks.demo import *
from judge.tasks.contest import *
from judge.tasks.submission import *
