class VanishedSubmission(Exception):
    pass
